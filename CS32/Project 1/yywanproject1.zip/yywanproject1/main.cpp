//
//  main.cpp
//  project1
//
//  Created by Yuen Yee Wan on 1/6/16.
//  Copyright © 2016 yywan. All rights reserved.
//

#include "History.h"
int main()
{
    History h;
}